#define _BUZZER_H
#ifdef _BUZZER_H
#define BUZZER 46

void buzzer_setting(void);

void buzzer_on(void);
void buzzer_off(void);

void buzzer_test(void);
#endif