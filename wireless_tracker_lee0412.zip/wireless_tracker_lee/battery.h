#ifndef _BATTERY_H
#define _BATTERY_H
#include "bsp.h"
void battery_init(void);
void battery_test(void);
#endif