#ifndef lorawan_h
#define lorawan_h

void lorawan_init();
void lorawan_loop();
#endif