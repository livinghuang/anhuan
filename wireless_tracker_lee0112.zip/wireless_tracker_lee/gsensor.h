#define _GSENSOR_H
#ifdef _GSENSOR_H
#include "MPU6050.h"

void gsensor_init(void);
void gsensor_test(void);
#endif