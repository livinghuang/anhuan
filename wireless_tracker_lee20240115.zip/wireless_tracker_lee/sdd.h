#define _SDD_H
#ifdef _SDD_H

void sd_init(void);
void sd_test(void);
#endif