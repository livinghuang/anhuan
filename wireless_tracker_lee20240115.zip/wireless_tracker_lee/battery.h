#define _BATTERY_H
#ifdef _BATTERY_H

void battery_init(void);
void battery_test(void);
#endif