#ifndef BLE_H
#define BLE_H
#include "bsp.h"
void ble_init();
void ble_process(void);
#endif