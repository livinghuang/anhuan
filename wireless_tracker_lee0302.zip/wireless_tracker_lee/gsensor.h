#ifndef _GSENSOR_H
#define _GSENSOR_H
#include "bsp.h"
#include "MPU6050.h"

void gsensor_init(void);
void gsensor_test(void);
#endif