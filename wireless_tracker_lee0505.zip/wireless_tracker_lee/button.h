#ifndef _BUTTON_H
#define _BUTTON_H
#include "bsp.h"

void button_setting(void);
void button_test(void);
#endif