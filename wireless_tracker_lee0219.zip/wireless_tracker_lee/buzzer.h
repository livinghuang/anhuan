#ifndef _BUZZER_H
#define _BUZZER_H
#include "bsp.h"

void buzzer_setting(void);

void buzzer_on(void);
void buzzer_off(void);

void buzzer_test(void);
#endif